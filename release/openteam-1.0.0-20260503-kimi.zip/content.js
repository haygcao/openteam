"use strict";
(() => {
  // src/content/conversationMonitor.ts
  function createConversationMonitor(options) {
    let lastReportedConversationKey = "";
    let conversationMonitorStarted = false;
    function reportConversationUpdate(force = false) {
      const assignedRole = options.roleSession.getAssignedRole();
      if (!assignedRole) return;
      const chatId = options.roleSession.getAssignedChatId(assignedRole);
      if (!chatId) return;
      const snapshot = options.siteAdapter.getConversationSnapshot();
      const key = `${chatId}:${assignedRole.roleId}:${snapshot.conversationId || ""}:${snapshot.conversationUrl || ""}`;
      if (!force && key === lastReportedConversationKey) return;
      lastReportedConversationKey = key;
      options.sendRuntimeMessage({
        type: "TEAM_ROLE_CONVERSATION_UPDATED",
        chatId,
        roleId: assignedRole.roleId,
        conversationId: snapshot.conversationId,
        conversationUrl: snapshot.conversationUrl
      }).catch((error) => options.log.warn("conversation-update:failed", { error: error instanceof Error ? error.message : String(error) }));
    }
    function start() {
      if (conversationMonitorStarted) return;
      conversationMonitorStarted = true;
      const notify = () => window.setTimeout(() => reportConversationUpdate(), 0);
      const originalPushState = history.pushState;
      const originalReplaceState = history.replaceState;
      history.pushState = function pushState(...args) {
        const result = originalPushState.apply(this, args);
        notify();
        return result;
      };
      history.replaceState = function replaceState(...args) {
        const result = originalReplaceState.apply(this, args);
        notify();
        return result;
      };
      window.addEventListener("popstate", notify);
      window.addEventListener("hashchange", notify);
      notify();
    }
    return { reportConversationUpdate, start };
  }

  // src/content/frameHandshake.ts
  var FRAME_ASSIGN_MESSAGE = "OPENTEAM_ASSIGN_FRAME_ROLE";
  function registerFrameRoleHandshake(options) {
    window.addEventListener("message", (event) => {
      if (!event.data || typeof event.data !== "object") return;
      if (event.data.type !== FRAME_ASSIGN_MESSAGE) return;
      const chatId = typeof event.data.chatId === "string" ? event.data.chatId : typeof event.data.roomId === "string" ? event.data.roomId : "";
      const roleId = typeof event.data.roleId === "string" ? event.data.roleId : "";
      const hostTabId = typeof event.data.hostTabId === "number" ? event.data.hostTabId : void 0;
      if (!roleId) return;
      const snapshot = options.siteAdapter.getConversationSnapshot();
      options.log.info("frame-role:assignment-received", { chatId, roleId, hostTabId, conversationId: snapshot.conversationId });
      options.sendRuntimeMessage({
        type: "TEAM_FRAME_ROLE_READY",
        chatId,
        roleId,
        hostTabId,
        conversationId: snapshot.conversationId || options.siteAdapter.getConversationId(),
        conversationUrl: snapshot.conversationUrl
      }).then((response) => {
        if (!response.ok || !response.role) {
          options.log.warn("frame-role:ready-failed", { roleId, error: response.error });
          return;
        }
        options.seedStoredRoleReplies(response.replyHistory);
        options.roleSession.assignRole({
          chatId,
          roleId: response.role.id,
          roleName: response.role.name,
          roomId: response.role.chatId || chatId
        });
      }).catch((error) => options.log.warn("frame-role:ready-error", { roleId, error: error instanceof Error ? error.message : String(error) }));
    });
  }

  // src/content/frameEnvironment.ts
  function isEmbeddedFrame() {
    try {
      return window.top !== window;
    } catch {
      return true;
    }
  }
  function isDirectEmbeddedFrame() {
    try {
      return window.top !== window && window.parent === window.top;
    } catch {
      return false;
    }
  }

  // src/content/promptDelay.ts
  var PROMPT_INPUT_DELAY_MS = 1500;
  function waitBeforePromptInput(delayMs = PROMPT_INPUT_DELAY_MS) {
    return new Promise((resolve) => {
      setTimeout(resolve, delayMs);
    });
  }

  // src/content/responseContainers.ts
  function keepDeepestResponseContainers(containers) {
    return containers.filter((candidate) => {
      return !containers.some((other) => other !== candidate && candidate.contains(other));
    });
  }

  // src/content/replyCompensation.ts
  function findLatestCompensationCandidate(input) {
    return keepDeepestResponseContainers(input.containers).map((element) => ({ element, text: input.readText(element).trim() })).filter((candidate) => candidate.text && !input.isBaseline(candidate.text, candidate.element)).reverse()[0];
  }
  function findLatestCompensationReply(input) {
    const candidates = keepDeepestResponseContainers(input.containers).map((element) => ({ element, text: input.readText(element).trim() })).filter((candidate) => candidate.text && !input.isBaseline(candidate.text, candidate.element));
    for (const candidate of candidates.reverse()) {
      if (input.consume(candidate.text, candidate.element)) return candidate;
    }
    return void 0;
  }

  // src/content/replyTimeout.ts
  function createReplyTimeout(timeoutMs, onTimeout) {
    let timer;
    let activeMessageId;
    return {
      arm(messageId) {
        this.clear();
        activeMessageId = messageId;
        timer = setTimeout(() => {
          const timedOutMessageId = activeMessageId;
          activeMessageId = void 0;
          timer = void 0;
          if (timedOutMessageId) onTimeout(timedOutMessageId);
        }, timeoutMs);
      },
      clear() {
        if (timer) clearTimeout(timer);
        timer = void 0;
        activeMessageId = void 0;
      }
    };
  }

  // src/content/replyTracker.ts
  function hashStr(value) {
    let hash = 0;
    for (let index = 0; index < value.length; index += 1) {
      hash = Math.imul(31, hash) + value.charCodeAt(index) | 0;
    }
    return hash >>> 0;
  }
  function replyKey(conversationId, text) {
    return String(hashStr(`${conversationId}:${text.trim()}`));
  }
  function createReplyTracker() {
    const seenReplyHashes = /* @__PURE__ */ new Set();
    const globallySeenReplyHashes = /* @__PURE__ */ new Set();
    const consumedMessageIds = /* @__PURE__ */ new Set();
    return {
      seed(conversationId, replies) {
        for (const reply of replies) {
          const trimmed = reply.trim();
          if (trimmed) seenReplyHashes.add(replyKey(conversationId, trimmed));
        }
      },
      seedGlobal(replies) {
        for (const reply of replies) {
          const trimmed = reply.trim();
          if (trimmed) globallySeenReplyHashes.add(String(hashStr(trimmed)));
        }
      },
      consumeIfNew(conversationId, reply) {
        const trimmed = reply.trim();
        if (!trimmed) return false;
        if (globallySeenReplyHashes.has(String(hashStr(trimmed)))) return false;
        const key = replyKey(conversationId, trimmed);
        if (seenReplyHashes.has(key)) return false;
        seenReplyHashes.add(key);
        return true;
      },
      consumeIfNewForMessage(conversationId, reply, messageId) {
        if (!messageId) return false;
        if (consumedMessageIds.has(messageId)) return false;
        if (!this.consumeIfNew(conversationId, reply)) return false;
        consumedMessageIds.add(messageId);
        return true;
      }
    };
  }

  // src/content/replyObserver.ts
  var RESPONSE_DEBOUNCE_MS = 2500;
  var RESPONSE_FINAL_SETTLE_MS = 1500;
  var RESPONSE_GENERATING_STABLE_GRACE_MS = 8e3;
  var REPLY_POLL_INTERVAL_MS = 2e3;
  var REPLY_TIMEOUT_MS = 12e4;
  var LONG_REPLY_TEXT_LENGTH = 160;
  var SHORT_COPY_TEXT_LENGTH = 40;
  var MIN_COPY_TO_DOM_TEXT_RATIO = 0.2;
  function createReplyObserver(options) {
    const { siteAdapter: siteAdapter2, roleSession: roleSession2, log } = options;
    let promptBaselineContainers = /* @__PURE__ */ new Set();
    let promptBaselineReplies = /* @__PURE__ */ new Set();
    let replyPollingTimer = null;
    let replyPollingInFlight = false;
    const replyTracker = createReplyTracker();
    const replyTimeout = createReplyTimeout(REPLY_TIMEOUT_MS, (messageId) => {
      const assignedRole = roleSession2.getAssignedRole();
      log.warn("reply-timeout", { messageId, roleId: assignedRole?.roleId, roleName: assignedRole?.roleName });
      if (tryReportLatestReply(messageId, "timeout-compensation")) return;
      const replyAttemptId = roleSession2.getActiveReplyAttemptId();
      roleSession2.clearActivePrompt(messageId);
      options.sendRuntimeMessage({
        type: "TEAM_ROLE_STATUS",
        status: "error",
        error: `\u7B49\u5F85 Gemini \u56DE\u590D\u8D85\u65F6\uFF08${Math.round(REPLY_TIMEOUT_MS / 1e3)} \u79D2\uFF09`
      }).catch((error) => log.warn("reply-timeout:status-failed", { error: error instanceof Error ? error.message : String(error) }));
      options.reportRoleError(messageId, `\u7B49\u5F85 Gemini \u56DE\u590D\u8D85\u65F6\uFF08${Math.round(REPLY_TIMEOUT_MS / 1e3)} \u79D2\uFF09`, void 0, void 0, replyAttemptId);
      clearReplyPolling();
    });
    function getConversationId() {
      return siteAdapter2.getConversationId();
    }
    function capturePromptReplyBaseline(messageId) {
      const containers = siteAdapter2.getResponseContainers();
      const replies = containers.map((container) => siteAdapter2.readResponseText(container)).filter(Boolean);
      promptBaselineContainers = new Set(containers);
      promptBaselineReplies = new Set(replies.map((reply) => reply.trim()).filter(Boolean));
      replyTracker.seed(getConversationId(), replies);
      log.debug("reply-baseline:captured", {
        messageId,
        conversationId: getConversationId(),
        containerCount: promptBaselineContainers.size,
        replyCount: promptBaselineReplies.size
      });
    }
    function clearPromptReplyBaseline() {
      promptBaselineContainers.clear();
      promptBaselineReplies.clear();
    }
    function seedStoredRoleReplies(replies) {
      const validReplies = (replies ?? []).map((reply) => reply.trim()).filter(Boolean);
      if (validReplies.length === 0) return;
      replyTracker.seedGlobal(validReplies);
      log.debug("reply-history:seeded", { count: validReplies.length, conversationId: getConversationId() });
    }
    function isPromptBaselineReply(text, element) {
      const trimmed = text.trim();
      if (!trimmed) return true;
      if (promptBaselineReplies.has(trimmed)) return true;
      for (const container of promptBaselineContainers) {
        if (container === element || container.contains(element) || element.contains(container)) return true;
      }
      return false;
    }
    function findCompensationReply(messageId) {
      return findLatestCompensationReply({
        containers: siteAdapter2.getResponseContainers(),
        readText: siteAdapter2.readResponseText,
        isBaseline: isPromptBaselineReply,
        consume: (text) => replyTracker.consumeIfNewForMessage(getConversationId(), text, messageId)
      });
    }
    function findCompensationCandidate() {
      return findLatestCompensationCandidate({
        containers: siteAdapter2.getResponseContainers(),
        readText: siteAdapter2.readResponseText,
        isBaseline: isPromptBaselineReply
      });
    }
    function clearReplyPolling() {
      if (replyPollingTimer) {
        window.clearTimeout(replyPollingTimer);
        replyPollingTimer = null;
      }
      replyPollingInFlight = false;
    }
    function startReplyPolling(messageId, replyAttemptId) {
      clearReplyPolling();
      replyTimeout.arm(messageId);
      let stableElement;
      let stableText = "";
      let stableSince = 0;
      const schedule = () => {
        replyPollingTimer = window.setTimeout(tick, REPLY_POLL_INTERVAL_MS);
      };
      const resetStableCandidate = () => {
        stableElement = void 0;
        stableText = "";
        stableSince = 0;
      };
      const tick = () => {
        replyPollingTimer = null;
        const activePrompt = roleSession2.getActivePrompt();
        if (activePrompt?.messageId !== messageId || activePrompt.replyAttemptId !== replyAttemptId) {
          clearReplyPolling();
          return;
        }
        if (replyPollingInFlight) {
          schedule();
          return;
        }
        const candidate = findCompensationCandidate();
        if (!candidate) {
          resetStableCandidate();
          schedule();
          return;
        }
        const timestamp = Date.now();
        const generating = siteAdapter2.isGenerating();
        if (candidate.element !== stableElement || candidate.text !== stableText) {
          stableElement = candidate.element;
          stableText = candidate.text;
          stableSince = timestamp;
          log.debug("reply-poll:candidate", { messageId, textLength: candidate.text.length });
          schedule();
          return;
        }
        const stableDuration = timestamp - stableSince;
        if (stableDuration < RESPONSE_FINAL_SETTLE_MS) {
          schedule();
          return;
        }
        if (generating && stableDuration < RESPONSE_GENERATING_STABLE_GRACE_MS) {
          log.debug("reply-poll:defer-generating", { messageId, stableDuration, textLength: candidate.text.length });
          schedule();
          return;
        }
        replyPollingInFlight = true;
        resolveReportableReplyText(candidate.element, candidate.text).then((reply) => {
          const active = roleSession2.getActivePrompt();
          const assignedRole = roleSession2.getAssignedRole();
          if (active?.messageId !== messageId || active.replyAttemptId !== replyAttemptId) return;
          if (!replyTracker.consumeIfNewForMessage(getConversationId(), reply.text, messageId)) {
            log.debug("reply-poll:skipped", { messageId, textLength: reply.text.length, roleId: assignedRole?.roleId });
            schedule();
            return;
          }
          log.warn("reply-poll:compensated", { messageId, textLength: reply.text.length, roleId: assignedRole?.roleId });
          reportAcceptedReply(messageId, reply, "polling-compensation");
        }).catch((error) => {
          log.warn("reply-poll:resolve-failed", { messageId, error: error instanceof Error ? error.message : String(error) });
          const active = roleSession2.getActivePrompt();
          if (active?.messageId === messageId && active.replyAttemptId === replyAttemptId) schedule();
        }).finally(() => {
          replyPollingInFlight = false;
        });
      };
      schedule();
    }
    function reportAcceptedReply(messageId, reply, source) {
      const assignedRole = roleSession2.getAssignedRole();
      if (!assignedRole) return;
      const replyAttemptId = roleSession2.clearActivePrompt(messageId);
      clearPromptReplyBaseline();
      replyTimeout.clear();
      clearReplyPolling();
      const text = reply.text;
      log.info("reply:accepted", { messageId, textLength: text.length, roleId: assignedRole.roleId, roleName: assignedRole.roleName, source });
      const snapshot = siteAdapter2.getConversationSnapshot();
      options.sendRuntimeMessage({
        type: "TEAM_ROLE_REPLY",
        chatId: roleSession2.getAssignedChatId(assignedRole),
        roleId: assignedRole.roleId,
        messageId,
        replyAttemptId,
        content: text,
        contentFormat: reply.contentFormat,
        conversationId: snapshot.conversationId,
        conversationUrl: snapshot.conversationUrl
      }).then(() => options.sendRuntimeMessage({ type: "TEAM_ROLE_STATUS", status: "idle" })).catch((error) => log.warn("reply:report-failed", { error: error instanceof Error ? error.message : String(error) }));
    }
    function tryReportLatestReply(messageId, source) {
      const assignedRole = roleSession2.getAssignedRole();
      if (!assignedRole) return false;
      const reply = findCompensationReply(messageId);
      if (!reply) return false;
      log.warn("reply:compensated", { messageId, textLength: reply.text.length, roleId: assignedRole.roleId, source });
      reportAcceptedReply(messageId, { text: reply.text }, source);
      return true;
    }
    async function resolveReportableReplyText(element, fallbackText) {
      try {
        const copiedText = await siteAdapter2.readResponseTextFromCopy?.(element);
        const trimmedCopiedText = copiedText?.trim();
        if (trimmedCopiedText && !isSuspiciousCopiedReply(trimmedCopiedText, fallbackText)) return { text: trimmedCopiedText, contentFormat: "markdown" };
        if (trimmedCopiedText) {
          log.warn("reply-copy:ignored-suspicious-short-text", {
            copiedLength: normalizeReplyForLengthCheck(trimmedCopiedText).length,
            domTextLength: normalizeReplyForLengthCheck(fallbackText).length
          });
        }
      } catch (error) {
        log.warn("reply-copy:failed", { error: error instanceof Error ? error.message : String(error) });
      }
      try {
        const markdownText = siteAdapter2.readResponseMarkdown?.(element).trim();
        if (markdownText) return { text: markdownText, contentFormat: "markdown" };
      } catch (error) {
        log.warn("reply-markdown:failed", { error: error instanceof Error ? error.message : String(error) });
      }
      return { text: fallbackText };
    }
    function isSuspiciousCopiedReply(copiedText, fallbackText) {
      const copiedLength = normalizeReplyForLengthCheck(copiedText).length;
      const fallbackLength = normalizeReplyForLengthCheck(fallbackText).length;
      if (fallbackLength < LONG_REPLY_TEXT_LENGTH) return false;
      if (copiedLength < SHORT_COPY_TEXT_LENGTH) return true;
      return copiedLength / fallbackLength < MIN_COPY_TO_DOM_TEXT_RATIO;
    }
    function normalizeReplyForLengthCheck(text) {
      return text.replace(/\s+/g, "");
    }
    function observeResponseContainers(onStableText) {
      let debounceTimer = null;
      const pendingContainers = /* @__PURE__ */ new Set();
      function flush() {
        if (debounceTimer) {
          window.clearTimeout(debounceTimer);
          debounceTimer = null;
        }
        const pendingCount = pendingContainers.size;
        const containers = keepDeepestResponseContainers([...pendingContainers]);
        const snapshots = containers.map((container) => ({ container, text: siteAdapter2.readResponseText(container) })).filter((snapshot) => Boolean(snapshot.text));
        log.debug("observer:flush", { pending: pendingCount, kept: containers.length, snapshots: snapshots.length });
        pendingContainers.clear();
        window.setTimeout(() => {
          const generating = siteAdapter2.isGenerating();
          for (const snapshot of snapshots) {
            if (!snapshot.container.isConnected) continue;
            const text = siteAdapter2.readResponseText(snapshot.container);
            if (!text) continue;
            if (generating || text !== snapshot.text) {
              log.debug("observer:defer-unstable", {
                generating,
                previousLength: snapshot.text.length,
                currentLength: text.length
              });
              schedule(snapshot.container);
              continue;
            }
            log.debug("observer:stable", { textLength: text.length });
            onStableText(text, snapshot.container);
          }
        }, RESPONSE_FINAL_SETTLE_MS);
      }
      function schedule(container) {
        pendingContainers.add(container);
        if (debounceTimer) window.clearTimeout(debounceTimer);
        debounceTimer = window.setTimeout(flush, RESPONSE_DEBOUNCE_MS);
      }
      function inspectNode(node) {
        if (node.nodeType === Node.TEXT_NODE) {
          const container2 = siteAdapter2.findResponseContainer(node.parentElement);
          if (container2) schedule(container2);
          return;
        }
        if (node.nodeType !== Node.ELEMENT_NODE) return;
        const element = node;
        const container = siteAdapter2.findResponseContainer(element);
        if (container) {
          schedule(container);
          return;
        }
        for (const responseContainer of siteAdapter2.getResponseContainers()) {
          if (element.contains(responseContainer)) schedule(responseContainer);
        }
      }
      new MutationObserver((mutations) => {
        for (const mutation of mutations) {
          if (mutation.type === "characterData") {
            inspectNode(mutation.target);
            continue;
          }
          mutation.addedNodes.forEach(inspectNode);
        }
      }).observe(document.body, { childList: true, subtree: true, characterData: true });
      requestAnimationFrame(() => {
        siteAdapter2.getResponseContainers().forEach(schedule);
      });
    }
    function startReplyReporting() {
      observeResponseContainers((text, element) => {
        const assignedRole = roleSession2.getAssignedRole();
        if (!assignedRole) return;
        const messageId = roleSession2.getActiveMessageId();
        if (!messageId) {
          log.debug("reply:skipped-no-active-message", { textLength: text.length, roleId: assignedRole.roleId });
          return;
        }
        if (messageId && isPromptBaselineReply(text, element)) {
          log.debug("reply:skipped-baseline", { messageId, textLength: text.length, roleId: assignedRole.roleId });
          return;
        }
        resolveReportableReplyText(element, text).then((reply) => {
          const currentRole = roleSession2.getAssignedRole();
          if (!currentRole) return;
          if (!replyTracker.consumeIfNewForMessage(getConversationId(), reply.text, messageId)) {
            log.debug("reply:skipped", { messageId, textLength: reply.text.length, roleId: currentRole.roleId });
            return;
          }
          reportAcceptedReply(messageId, reply, "observer");
        }).catch(() => {
          const currentRole = roleSession2.getAssignedRole();
          if (!currentRole) return;
          if (!replyTracker.consumeIfNewForMessage(getConversationId(), text, messageId)) {
            log.debug("reply:skipped", { messageId, textLength: text.length, roleId: currentRole.roleId });
            return;
          }
          reportAcceptedReply(messageId, { text }, "observer");
        });
      });
    }
    function resetForAssignedRole() {
      clearPromptReplyBaseline();
      replyTimeout.clear();
      clearReplyPolling();
      replyTracker.seed(getConversationId(), siteAdapter2.getAllAssistantReplies());
    }
    return {
      capturePromptReplyBaseline,
      clearPromptReplyBaseline,
      clearReplyPolling,
      startReplyPolling,
      startReplyReporting,
      seedStoredRoleReplies,
      resetForAssignedRole
    };
  }

  // src/shared/logger.ts
  function createLogger(scope, baseContext = {}, options = {}) {
    const shouldEmitVerbose = () => options.debugEnabled ?? isDebugLoggingEnabled();
    const emit = (level, event, details = {}) => {
      if ((level === "debug" || level === "info") && !shouldEmitVerbose()) return;
      const payload = { ...baseContext, ...details };
      console[level](`[OpenTeam][${scope}] ${event}`, payload);
    };
    return {
      debug: (event, details) => emit("debug", event, details),
      info: (event, details) => emit("info", event, details),
      warn: (event, details) => emit("warn", event, details),
      error: (event, details) => emit("error", event, details),
      child: (context) => createLogger(scope, { ...baseContext, ...context }, options)
    };
  }
  function isDebugLoggingEnabled() {
    if (false) return true;
    try {
      const globalRecord = globalThis;
      if (globalRecord.OPENTEAM_DEBUG === true) return true;
      if (globalRecord.localStorage?.getItem("openteam:debug") === "true") return true;
      if (globalRecord.location?.search.includes("openteam_debug=1")) return true;
    } catch {
    }
    return false;
  }

  // src/content/runtimeClient.ts
  var contentLog = createLogger("content");
  async function sendRuntimeMessage(message, log = contentLog) {
    return new Promise((resolve, reject) => {
      log.debug("runtime-send:start", { type: message.type });
      chrome.runtime.sendMessage(message, (response) => {
        const error = chrome.runtime.lastError;
        if (error) {
          log.warn("runtime-send:failed", { type: message.type, error: error.message });
          reject(new Error(error.message));
          return;
        }
        log.debug("runtime-send:response", { type: message.type, response });
        resolve(response);
      });
    });
  }

  // src/content/roleSession.ts
  function createRoleSession(options) {
    let assignedRole = null;
    let activeMessageId;
    let activeReplyAttemptId;
    const getAssignedChatId = (role = assignedRole) => role?.chatId || role?.roomId || "";
    return {
      getAssignedRole: () => assignedRole,
      getActivePrompt: () => activeMessageId ? { messageId: activeMessageId, replyAttemptId: activeReplyAttemptId } : void 0,
      getActiveMessageId: () => activeMessageId,
      getActiveReplyAttemptId: () => activeReplyAttemptId,
      getAssignedChatId,
      assignRole(role) {
        assignedRole = role;
        activeMessageId = void 0;
        activeReplyAttemptId = void 0;
        options.onAssigned?.(role);
        options.log.info("role-assigned", {
          chatId: getAssignedChatId(role),
          roleId: role.roleId,
          roleName: role.roleName,
          roomId: role.roomId,
          conversationId: options.siteAdapter.getConversationId()
        });
      },
      startPrompt(messageId, replyAttemptId) {
        activeMessageId = messageId;
        activeReplyAttemptId = replyAttemptId;
      },
      clearActivePrompt(messageId) {
        if (messageId && activeMessageId !== messageId) return activeReplyAttemptId;
        const replyAttemptId = activeReplyAttemptId;
        activeMessageId = void 0;
        activeReplyAttemptId = void 0;
        return replyAttemptId;
      }
    };
  }

  // src/content/sites/waitForElement.ts
  function querySelectorFirst(selectors) {
    for (const selector of selectors.split(",").map((item) => item.trim())) {
      const element = document.querySelector(selector);
      if (element) return element;
    }
    return null;
  }
  function waitForElement(selectors, timeoutMs) {
    const immediate = querySelectorFirst(selectors);
    if (immediate) return Promise.resolve(immediate);
    return new Promise((resolve, reject) => {
      const startedAt = Date.now();
      const timer = window.setInterval(() => {
        const element = querySelectorFirst(selectors);
        if (element) {
          window.clearInterval(timer);
          resolve(element);
          return;
        }
        if (Date.now() - startedAt >= timeoutMs) {
          window.clearInterval(timer);
          reject(new Error(`Element not found: ${selectors}`));
        }
      }, 250);
    });
  }
  function waitForClickableButton(selectors, timeoutMs, errorMessage) {
    return new Promise((resolve, reject) => {
      const startedAt = Date.now();
      const timer = window.setInterval(() => {
        const button = querySelectorFirst(selectors);
        if (button && isClickableButton(button)) {
          window.clearInterval(timer);
          resolve(button);
          return;
        }
        if (Date.now() - startedAt >= timeoutMs) {
          window.clearInterval(timer);
          reject(new Error(errorMessage));
        }
      }, 250);
    });
  }
  function isClickableButton(element) {
    if (!(element instanceof HTMLButtonElement)) return true;
    return !element.disabled && element.getAttribute("aria-disabled") !== "true";
  }

  // src/content/sites/clipboardCopy.ts
  async function readResponseTextFromCopyAction(options) {
    if (options.node.nodeType !== Node.ELEMENT_NODE) return void 0;
    const copyButton = options.findCopyButton(options.node);
    const clipboard = navigator.clipboard;
    if (!copyButton || !clipboard?.readText) return void 0;
    let previousText;
    try {
      previousText = await clipboard.readText();
    } catch {
      return void 0;
    }
    try {
      copyButton.click();
      const copiedText = await waitForClipboardText(previousText, options.timeoutMs, options.pollMs);
      return copiedText?.trim() || void 0;
    } catch {
      return void 0;
    } finally {
      if (clipboard.writeText) {
        clipboard.writeText(previousText).catch(() => void 0);
      }
    }
  }
  function findClickableCopyButton(scope, selectors) {
    const copyButton = scope?.querySelector(selectors);
    return copyButton && isClickableButton(copyButton) ? copyButton : void 0;
  }
  function waitForClipboardText(previousText, timeoutMs, pollMs) {
    const clipboard = navigator.clipboard;
    if (!clipboard?.readText) return Promise.resolve(void 0);
    return new Promise((resolve) => {
      const startedAt = Date.now();
      const timer = window.setInterval(() => {
        clipboard.readText().then((text) => {
          const trimmed = text.trim();
          if (trimmed && (previousText === void 0 || text !== previousText)) {
            window.clearInterval(timer);
            resolve(text);
            return;
          }
          if (Date.now() - startedAt >= timeoutMs) {
            window.clearInterval(timer);
            resolve(void 0);
          }
        }).catch(() => {
          window.clearInterval(timer);
          resolve(void 0);
        });
      }, pollMs);
    });
  }

  // src/content/sites/contentEditable.ts
  function setContentEditableText(editor, content) {
    editor.focus();
    editor.replaceChildren();
    const block2 = document.createElement("p");
    block2.textContent = content;
    editor.append(block2);
    editor.dispatchEvent(new InputEvent("beforeinput", { bubbles: true, inputType: "insertText", data: content }));
    editor.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: content }));
    editor.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function readEditorText(editor, options = {}) {
    const raw = editor.innerText || editor.textContent || "";
    const text = options.normalizeNbsp ? raw.replace(/\u00a0/g, " ") : raw;
    return text.trim();
  }

  // src/content/sites/domMarkdown.ts
  var SKIP_SELECTORS = "button, svg, style, script, textarea, mat-icon";
  function extractMarkdownFromDom(node) {
    return normalizeMarkdown(block(node));
  }
  function block(node, depth = 0) {
    if (node.nodeType === Node.TEXT_NODE) return node.textContent || "";
    if (node.nodeType !== Node.ELEMENT_NODE) return "";
    const element = node;
    const tag = element.tagName.toLowerCase();
    if (element.getAttribute("aria-hidden") === "true") return "";
    if (element.matches(SKIP_SELECTORS)) return "";
    if (tag === "pre") {
      const code = element.querySelector("code")?.textContent ?? element.textContent ?? "";
      return `
\`\`\`
${code.trim()}
\`\`\`
`;
    }
    if (/^h[1-6]$/.test(tag)) {
      const level = Number(tag.slice(1));
      return `
${"#".repeat(level)} ${plainText(element)}
`;
    }
    if (tag === "p") return `
${inlineChildren(element).trim()}
`;
    if (tag === "blockquote") {
      return `
${plainText(element).split("\n").map((line) => `> ${line}`).join("\n")}
`;
    }
    if (tag === "ul") {
      return `
${[...element.children].map((item) => `${"  ".repeat(depth)}- ${listItemText(item, depth)}`).join("\n")}
`;
    }
    if (tag === "ol") {
      return `
${[...element.children].map((item, index) => `${"  ".repeat(depth)}${index + 1}. ${listItemText(item, depth)}`).join("\n")}
`;
    }
    if (tag === "table") return tableMarkdown(element);
    return [...element.childNodes].map((child) => block(child, depth)).join("");
  }
  function inline(node) {
    if (node.nodeType === Node.TEXT_NODE) return node.textContent || "";
    if (node.nodeType !== Node.ELEMENT_NODE) return "";
    const element = node;
    const tag = element.tagName.toLowerCase();
    if (element.getAttribute("aria-hidden") === "true") return "";
    if (element.matches(SKIP_SELECTORS)) return "";
    const content = inlineChildren(element);
    if (tag === "strong" || tag === "b") return `**${content}**`;
    if (tag === "em" || tag === "i") return `*${content}*`;
    if (tag === "code") return `\`${content}\``;
    if (tag === "a") {
      const href = element.getAttribute("href");
      return href ? `[${content}](${href})` : content;
    }
    if (tag === "br") return "\n";
    return content;
  }
  function inlineChildren(element) {
    return [...element.childNodes].map(inline).join("");
  }
  function listItemText(element, depth) {
    const inlinePart = [...element.childNodes].filter((child) => child.nodeType !== Node.ELEMENT_NODE || !["UL", "OL"].includes(child.tagName)).map(inline).join("").trim();
    const nestedPart = [...element.children].filter((child) => child.tagName === "UL" || child.tagName === "OL").map((child) => block(child, depth + 1).trimEnd()).join("\n");
    return [inlinePart, nestedPart].filter(Boolean).join("\n");
  }
  function tableMarkdown(element) {
    const rows = [...element.querySelectorAll("tr")].map((row) => [...row.children].map((cell) => plainText(cell)).join(" | "));
    if (rows.length === 0) return "";
    const separator = rows[0].split("|").map(() => " --- ").join("|");
    return `
${[rows[0], separator, ...rows.slice(1)].join("\n")}
`;
  }
  function plainText(element) {
    return (element.textContent || "").replace(/\s+/g, " ").trim();
  }
  function normalizeMarkdown(value) {
    return value.replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  }

  // src/content/sites/domText.ts
  var DEFAULT_BLOCK_TAGS = /* @__PURE__ */ new Set([
    "P",
    "DIV",
    "BR",
    "LI",
    "TR",
    "PRE",
    "BLOCKQUOTE",
    "H1",
    "H2",
    "H3",
    "H4",
    "H5",
    "H6"
  ]);
  function extractCleanTextFromDom(node, options) {
    const buffer = [];
    const blockTags = options.blockTags ?? DEFAULT_BLOCK_TAGS;
    function visit(current) {
      if (current.nodeType === Node.TEXT_NODE) {
        buffer.push(current.textContent || "");
        return;
      }
      if (current.nodeType !== Node.ELEMENT_NODE) return;
      const element = current;
      if (element.getAttribute("aria-hidden") === "true") return;
      if (options.skipTags.has(element.tagName)) return;
      if (blockTags.has(element.tagName)) buffer.push("\n");
      for (const child of element.childNodes) {
        visit(child);
      }
    }
    visit(node);
    return buffer.join("").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  }
  function findClosestMatchingAncestor(element, selectors) {
    while (element) {
      if (element.matches(selectors)) return element;
      element = element.parentElement;
    }
    return null;
  }
  function describeElement(element) {
    const htmlElement = element;
    return {
      tagName: element.tagName,
      id: htmlElement.id || void 0,
      className: typeof htmlElement.className === "string" ? htmlElement.className.slice(0, 120) : void 0,
      role: element.getAttribute("role") || void 0,
      ariaLabel: element.getAttribute("aria-label") || void 0,
      ariaDisabled: element.getAttribute("aria-disabled") || void 0,
      disabled: element instanceof HTMLButtonElement ? element.disabled : void 0,
      contentEditable: htmlElement.contentEditable || void 0
    };
  }
  function buttonLabelMatches(button, pattern) {
    const label = [button.getAttribute("aria-label"), button.getAttribute("title"), button.textContent].filter(Boolean).join(" ").toLowerCase();
    return pattern.test(label);
  }

  // src/content/sites/claude.ts
  var CLAUDE_HOSTS = /* @__PURE__ */ new Set(["claude.ai"]);
  var DEFAULT_INPUT_TIMEOUT_MS = 9e3;
  var DEFAULT_CLIPBOARD_TIMEOUT_MS = 900;
  var DEFAULT_CLIPBOARD_POLL_MS = 40;
  var CLAUDE_SELECTORS = {
    editor: '[data-testid="chat-input"][contenteditable="true"], div[contenteditable="true"][aria-label*="Claude"]',
    sendButton: 'button[aria-label*="Send"], button[aria-label*="\u53D1\u9001"], button[aria-label*="Submit"], button[aria-label*="\u53D1\u9001\u6D88\u606F"]',
    response: ".font-claude-response",
    copyButton: 'button[data-testid="action-bar-copy"], [role="group"][aria-label="Message actions"] button[aria-label="Copy"], button[aria-label="Copy"], button[aria-label="\u590D\u5236"]'
  };
  var SKIP_TAGS = /* @__PURE__ */ new Set(["SCRIPT", "STYLE", "BUTTON", "TEXTAREA", "SVG"]);
  function createClaudeAdapter(options = {}) {
    const inputTimeoutMs = options.inputTimeoutMs ?? DEFAULT_INPUT_TIMEOUT_MS;
    const clipboardTimeoutMs = options.clipboardTimeoutMs ?? DEFAULT_CLIPBOARD_TIMEOUT_MS;
    const clipboardPollMs = options.clipboardPollMs ?? DEFAULT_CLIPBOARD_POLL_MS;
    function currentHref() {
      return options.href ?? location.href;
    }
    function getConversationSnapshot() {
      return getClaudeConversationLocation(currentHref());
    }
    function getConversationId() {
      return getConversationSnapshot().conversationId || "__default__";
    }
    function getResponseContainers() {
      return [...document.querySelectorAll(CLAUDE_SELECTORS.response)];
    }
    function getAllAssistantReplies() {
      return keepDeepestResponseContainers(getResponseContainers()).map((container) => extractCleanText(container)).filter(Boolean);
    }
    async function fillAndSend2(content, autoSend = true) {
      const editor = await waitForElement(CLAUDE_SELECTORS.editor, inputTimeoutMs);
      setContentEditableText(editor, content);
      if (readEditorText(editor, { normalizeNbsp: true }) !== content.trim()) {
        throw new Error("Claude editor did not accept the prompt text");
      }
      if (!autoSend) return;
      const sendButton = await waitForClickableButton(CLAUDE_SELECTORS.sendButton, inputTimeoutMs, "Claude \u53D1\u9001\u6309\u94AE\u6682\u4E0D\u53EF\u7528\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5");
      sendButton.click();
    }
    return {
      id: "claude",
      getConversationSnapshot,
      getConversationId,
      getResponseContainers,
      getAllAssistantReplies,
      readResponseText: extractCleanText,
      readResponseTextFromCopy: (node) => readResponseTextFromCopy(node, clipboardTimeoutMs, clipboardPollMs),
      readResponseMarkdown: extractMarkdownFromDom,
      findResponseContainer,
      isGenerating: isClaudeGenerating,
      stopGenerating: stopClaudeGenerating,
      fillAndSend: fillAndSend2,
      collectPromptDiagnostics
    };
  }
  function getClaudeConversationLocation(href) {
    const url = parseSafeClaudeUrl(href);
    if (!url) return {};
    return {
      conversationId: extractConversationId(url),
      conversationUrl: url.href
    };
  }
  function parseSafeClaudeUrl(value) {
    if (!value) return void 0;
    try {
      const url = new URL(value);
      return url.protocol === "https:" && CLAUDE_HOSTS.has(url.hostname) ? url : void 0;
    } catch {
      return void 0;
    }
  }
  function extractConversationId(url) {
    if (!url.pathname.startsWith("/chat/")) return void 0;
    const conversationId = url.pathname.slice("/chat/".length).split("/")[0];
    return conversationId ? decodeURIComponent(conversationId) : void 0;
  }
  function collectPromptDiagnostics() {
    return {
      href: location.href,
      readyState: document.readyState,
      visibilityState: document.visibilityState,
      title: document.title,
      editorMatches: [...document.querySelectorAll(CLAUDE_SELECTORS.editor)].slice(0, 5).map(describeElement),
      sendButtonMatches: [...document.querySelectorAll(CLAUDE_SELECTORS.sendButton)].slice(0, 5).map(describeElement),
      visibleButtonSamples: [...document.querySelectorAll("button")].slice(0, 12).map(describeElement)
    };
  }
  function extractCleanText(node) {
    return extractCleanTextFromDom(node, { skipTags: SKIP_TAGS });
  }
  function findResponseContainer(element) {
    return findClosestMatchingAncestor(element, CLAUDE_SELECTORS.response);
  }
  async function readResponseTextFromCopy(node, timeoutMs, pollMs) {
    return readResponseTextFromCopyAction({ node, timeoutMs, pollMs, findCopyButton });
  }
  function findCopyButton(response) {
    let scope = response;
    while (scope && scope !== document.body) {
      const copyButton = findClickableCopyButton(scope, CLAUDE_SELECTORS.copyButton);
      if (copyButton) return copyButton;
      scope = scope.parentElement;
    }
    return findClickableCopyButton(document.body, CLAUDE_SELECTORS.copyButton);
  }
  function isClaudeGenerating() {
    return Boolean(findClaudeStopButton());
  }
  async function stopClaudeGenerating() {
    const button = findClaudeStopButton();
    if (!button) return false;
    button.click();
    return true;
  }
  function findClaudeStopButton() {
    return [...document.querySelectorAll("button")].find((button) => buttonLabelMatches(button, /stop|stopping|停止|中止/) && isClickableButton(button));
  }

  // src/content/sites/chatgpt.ts
  var CHATGPT_HOSTS = /* @__PURE__ */ new Set(["chatgpt.com", "chat.openai.com"]);
  var DEFAULT_INPUT_TIMEOUT_MS2 = 9e3;
  var DEFAULT_CLIPBOARD_TIMEOUT_MS2 = 900;
  var DEFAULT_CLIPBOARD_POLL_MS2 = 40;
  var CHATGPT_SELECTORS = {
    editor: 'form[data-type="unified-composer"] #prompt-textarea[contenteditable="true"], #prompt-textarea.ProseMirror[contenteditable="true"]',
    sendButton: 'button[data-testid="send-button"], button[aria-label*="\u53D1\u9001"], button[aria-label*="Send"], button[aria-label*="\u63D0\u4EA4"], button[aria-label*="Submit"]',
    response: '[data-message-author-role="assistant"]',
    responseActions: '[role="group"][aria-label="\u56DE\u590D\u64CD\u4F5C"], [role="group"][aria-label="Message actions"], [aria-label="\u56DE\u590D\u64CD\u4F5C"], [aria-label="Message actions"]',
    turnCopyButton: 'button[data-testid="copy-turn-action-button"], button[aria-label="\u590D\u5236\u56DE\u590D"], button[aria-label="Copy response"]',
    copyButton: 'button[data-testid="copy-turn-action-button"], button[aria-label="\u590D\u5236\u56DE\u590D"], button[aria-label="Copy response"], button[aria-label="\u590D\u5236"], button[aria-label="Copy"]',
    turn: 'section[data-turn="assistant"][data-testid^="conversation-turn-"], [data-turn="assistant"][data-testid^="conversation-turn-"]'
  };
  var SKIP_TAGS2 = /* @__PURE__ */ new Set(["SCRIPT", "STYLE", "BUTTON", "TEXTAREA", "SVG"]);
  function createChatGptAdapter(options = {}) {
    const inputTimeoutMs = options.inputTimeoutMs ?? DEFAULT_INPUT_TIMEOUT_MS2;
    const clipboardTimeoutMs = options.clipboardTimeoutMs ?? DEFAULT_CLIPBOARD_TIMEOUT_MS2;
    const clipboardPollMs = options.clipboardPollMs ?? DEFAULT_CLIPBOARD_POLL_MS2;
    function currentHref() {
      return options.href ?? location.href;
    }
    function getConversationSnapshot() {
      return getChatGptConversationLocation(currentHref());
    }
    function getConversationId() {
      return getConversationSnapshot().conversationId || "__default__";
    }
    function getResponseContainers() {
      const turnResponses = [...document.querySelectorAll(CHATGPT_SELECTORS.turn)].map((turn) => findPrimaryResponseInTurn(turn)).filter((response) => Boolean(response));
      if (turnResponses.length > 0) return turnResponses;
      return [...document.querySelectorAll(CHATGPT_SELECTORS.response)];
    }
    function getAllAssistantReplies() {
      return keepDeepestResponseContainers(getResponseContainers()).map((container) => extractCleanText2(container)).filter(Boolean);
    }
    async function fillAndSend2(content, autoSend = true) {
      const editor = await waitForElement(CHATGPT_SELECTORS.editor, inputTimeoutMs);
      setContentEditableText(editor, content);
      if (readEditorText(editor) !== content.trim()) {
        throw new Error("ChatGPT editor did not accept the prompt text");
      }
      if (!autoSend) return;
      const sendButton = await waitForClickableButton(CHATGPT_SELECTORS.sendButton, inputTimeoutMs, "ChatGPT \u53D1\u9001\u6309\u94AE\u6682\u4E0D\u53EF\u7528\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5");
      sendButton.click();
    }
    return {
      id: "chatgpt",
      getConversationSnapshot,
      getConversationId,
      getResponseContainers,
      getAllAssistantReplies,
      readResponseText: extractCleanText2,
      readResponseTextFromCopy: (node) => readResponseTextFromCopy2(node, clipboardTimeoutMs, clipboardPollMs),
      readResponseMarkdown: extractMarkdownFromDom,
      findResponseContainer: findResponseContainer2,
      isGenerating: isChatGptGenerating,
      stopGenerating: stopChatGptGenerating,
      fillAndSend: fillAndSend2,
      collectPromptDiagnostics: collectPromptDiagnostics2
    };
  }
  async function readResponseTextFromCopy2(node, timeoutMs, pollMs) {
    return readResponseTextFromCopyAction({ node, timeoutMs, pollMs, findCopyButton: findCopyButton2 });
  }
  function findCopyButton2(response) {
    const turn = response.closest(CHATGPT_SELECTORS.turn) ?? response.parentElement;
    const turnActionCopyButton = findTurnActionCopyButton(turn);
    if (turnActionCopyButton) return turnActionCopyButton;
    return findLastClickableCopyButton(turn, CHATGPT_SELECTORS.copyButton);
  }
  function findTurnActionCopyButton(turn) {
    const actions = turn?.querySelector(CHATGPT_SELECTORS.responseActions);
    const button = actions?.querySelector(CHATGPT_SELECTORS.turnCopyButton);
    return button && isClickableButton(button) ? button : void 0;
  }
  function findLastClickableCopyButton(scope, selectors) {
    const buttons = [...scope?.querySelectorAll(selectors) ?? []];
    return buttons.reverse().find((button) => isClickableButton(button) && isVisibleElement(button));
  }
  function getChatGptConversationLocation(href) {
    const url = parseSafeChatGptUrl(href);
    if (!url) return {};
    return {
      conversationId: extractConversationId2(url),
      conversationUrl: url.href
    };
  }
  function parseSafeChatGptUrl(value) {
    if (!value) return void 0;
    try {
      const url = new URL(value);
      return url.protocol === "https:" && CHATGPT_HOSTS.has(url.hostname) ? url : void 0;
    } catch {
      return void 0;
    }
  }
  function extractConversationId2(url) {
    if (!url.pathname.startsWith("/c/")) return void 0;
    const conversationId = url.pathname.slice("/c/".length).split("/")[0];
    return conversationId ? decodeURIComponent(conversationId) : void 0;
  }
  function collectPromptDiagnostics2() {
    return {
      href: location.href,
      readyState: document.readyState,
      visibilityState: document.visibilityState,
      title: document.title,
      editorMatches: [...document.querySelectorAll(CHATGPT_SELECTORS.editor)].slice(0, 5).map(describeElement),
      sendButtonMatches: [...document.querySelectorAll(CHATGPT_SELECTORS.sendButton)].slice(0, 5).map(describeElement),
      visibleButtonSamples: [...document.querySelectorAll("button")].slice(0, 12).map(describeElement)
    };
  }
  function extractCleanText2(node) {
    return extractCleanTextFromDom(node, { skipTags: SKIP_TAGS2 });
  }
  function findResponseContainer2(element) {
    const turn = element?.closest(CHATGPT_SELECTORS.turn);
    const turnResponse = turn ? findPrimaryResponseInTurn(turn) : null;
    return turnResponse ?? findClosestMatchingAncestor(element, CHATGPT_SELECTORS.response);
  }
  function isChatGptGenerating() {
    return Boolean(findChatGptStopButton());
  }
  async function stopChatGptGenerating() {
    const button = findChatGptStopButton();
    if (!button) return false;
    button.click();
    return true;
  }
  function findChatGptStopButton() {
    return [...document.querySelectorAll("button")].find((button) => buttonLabelMatches(button, /stop|stopping|停止|中止/) && isClickableButton(button) && isVisibleInteractiveElement(button));
  }
  function findPrimaryResponseInTurn(turn) {
    return turn.querySelector('[data-message-author-role="assistant"][data-turn-start-message="true"]') ?? turn.querySelector('[data-message-author-role="assistant"][data-message-id]') ?? turn.querySelector(CHATGPT_SELECTORS.response);
  }
  function isVisibleElement(element) {
    const style = window.getComputedStyle(element);
    if (style.display === "none" || style.visibility === "hidden" || style.opacity === "0") return false;
    return element.getClientRects().length > 0 || Boolean(element.offsetParent);
  }
  function isVisibleInteractiveElement(element) {
    const style = window.getComputedStyle(element);
    if (style.pointerEvents === "none") return false;
    return isVisibleElement(element);
  }

  // src/content/sites/deepseek.ts
  var DEEPSEEK_HOST = "chat.deepseek.com";
  var DEEPSEEK_ORIGIN = `https://${DEEPSEEK_HOST}`;
  var DEEPSEEK_HOME_URL = `${DEEPSEEK_ORIGIN}/`;
  var DEFAULT_INPUT_TIMEOUT_MS3 = 9e3;
  var DEEPSEEK_SELECTORS = {
    editor: 'textarea[name="search"], textarea[placeholder*="DeepSeek"], textarea[placeholder*="\u53D1\u9001\u6D88\u606F"]',
    response: "[data-virtual-list-item-key] .ds-message .ds-markdown:not(.ds-think-content .ds-markdown)",
    responseContainer: "[data-virtual-list-item-key]",
    composer: '.aaff8b8f, ._77cefa5, [class*="composer"]',
    sendButton: '.bf38813a [role="button"], .bf38813a button, [role="button"]._52c986b, button._52c986b'
  };
  var SKIP_TAGS3 = /* @__PURE__ */ new Set(["SCRIPT", "STYLE", "BUTTON", "TEXTAREA", "SVG"]);
  function createDeepSeekAdapter(options = {}) {
    const inputTimeoutMs = options.inputTimeoutMs ?? DEFAULT_INPUT_TIMEOUT_MS3;
    function currentHref() {
      return options.href ?? location.href;
    }
    function getConversationSnapshot() {
      return getDeepSeekConversationLocation(currentHref());
    }
    function getConversationId() {
      return getConversationSnapshot().conversationId || "__default__";
    }
    function getResponseContainers() {
      return [...document.querySelectorAll(DEEPSEEK_SELECTORS.response)].filter(isFinalResponseMarkdown);
    }
    function getAllAssistantReplies() {
      return keepDeepestResponseContainers(getResponseContainers()).map((container) => extractCleanText3(container)).filter(Boolean);
    }
    async function fillAndSend2(content, autoSend = true) {
      const editor = await waitForElement(DEEPSEEK_SELECTORS.editor, inputTimeoutMs);
      if (!(editor instanceof HTMLTextAreaElement)) {
        throw new Error("DeepSeek editor is not a textarea");
      }
      setTextareaText(editor, content);
      if (editor.value.trim() !== content.trim()) {
        throw new Error("DeepSeek editor did not accept the prompt text");
      }
      if (!autoSend) return;
      const sendButton = await waitForDeepSeekSendButton(editor, inputTimeoutMs);
      sendButton.click();
    }
    return {
      id: "deepseek",
      getConversationSnapshot,
      getConversationId,
      getResponseContainers,
      getAllAssistantReplies,
      readResponseText: extractCleanText3,
      readResponseMarkdown: extractMarkdownFromDom,
      findResponseContainer: findResponseContainer3,
      isGenerating: isDeepSeekGenerating,
      stopGenerating: stopDeepSeekGenerating,
      fillAndSend: fillAndSend2,
      collectPromptDiagnostics: collectPromptDiagnostics3
    };
  }
  function getDeepSeekConversationLocation(href) {
    const url = parseSafeDeepSeekUrl(href);
    if (!url) return {};
    return {
      conversationId: extractConversationId3(url),
      conversationUrl: url.href
    };
  }
  function parseSafeDeepSeekUrl(value) {
    if (!value || !value.startsWith(DEEPSEEK_HOME_URL)) return void 0;
    try {
      const url = new URL(value);
      return url.protocol === "https:" && url.hostname === DEEPSEEK_HOST ? url : void 0;
    } catch {
      return void 0;
    }
  }
  function extractConversationId3(url) {
    const match = url.pathname.match(/^\/a\/chat\/s\/([^/]+)/);
    const conversationId = match?.[1];
    return conversationId ? decodeURIComponent(conversationId) : void 0;
  }
  function setTextareaText(textarea, content) {
    textarea.focus();
    textarea.value = content;
    textarea.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: content }));
    textarea.dispatchEvent(new Event("change", { bubbles: true }));
  }
  async function waitForDeepSeekSendButton(editor, timeoutMs) {
    const startedAt = Date.now();
    while (Date.now() - startedAt <= timeoutMs) {
      const button = findDeepSeekSendButton(editor);
      if (button) return button;
      await new Promise((resolve) => window.setTimeout(resolve, 50));
    }
    throw new Error("DeepSeek \u53D1\u9001\u6309\u94AE\u6682\u4E0D\u53EF\u7528\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5");
  }
  function findDeepSeekSendButton(editor) {
    const composer = editor.closest(DEEPSEEK_SELECTORS.composer) ?? document.body;
    const candidates = [...composer.querySelectorAll(DEEPSEEK_SELECTORS.sendButton)];
    return candidates.reverse().find(isDeepSeekSendButton);
  }
  function isDeepSeekSendButton(element) {
    if (element.getAttribute("aria-disabled") === "true") return false;
    if (element instanceof HTMLButtonElement && element.disabled) return false;
    if (element.classList.contains("ds-toggle-button")) return false;
    if (!element.classList.contains("ds-icon-button") && !element.querySelector(".ds-icon")) return false;
    return isVisibleInteractiveElement2(element);
  }
  function collectPromptDiagnostics3() {
    return {
      href: location.href,
      readyState: document.readyState,
      visibilityState: document.visibilityState,
      title: document.title,
      editorMatches: [...document.querySelectorAll(DEEPSEEK_SELECTORS.editor)].slice(0, 5).map(describeElement),
      sendButtonMatches: [...document.querySelectorAll(DEEPSEEK_SELECTORS.sendButton)].slice(0, 5).map(describeElement),
      visibleButtonSamples: [...document.querySelectorAll('[role="button"], button')].slice(0, 12).map(describeElement)
    };
  }
  function extractCleanText3(node) {
    return extractCleanTextFromDom(node, { skipTags: SKIP_TAGS3 });
  }
  function findResponseContainer3(element) {
    const finalMarkdown = findClosestMatchingAncestor(element, DEEPSEEK_SELECTORS.response);
    return finalMarkdown && isFinalResponseMarkdown(finalMarkdown) ? finalMarkdown : null;
  }
  function isFinalResponseMarkdown(element) {
    if (element.closest(".ds-think-content")) return false;
    return Boolean(element.closest(DEEPSEEK_SELECTORS.responseContainer));
  }
  function isDeepSeekGenerating() {
    return Boolean(findDeepSeekStopButton());
  }
  async function stopDeepSeekGenerating() {
    const button = findDeepSeekStopButton();
    if (!button) return false;
    button.click();
    return true;
  }
  function findDeepSeekStopButton() {
    return [...document.querySelectorAll('[role="button"], button')].find((button) => buttonLabelMatches(button, /stop|stopping|停止|中止/) && isClickableDeepSeekButton(button));
  }
  function isClickableDeepSeekButton(element) {
    if (element.getAttribute("aria-disabled") === "true") return false;
    if (element instanceof HTMLButtonElement) return isClickableButton(element);
    return isVisibleInteractiveElement2(element);
  }
  function isVisibleInteractiveElement2(element) {
    const style = window.getComputedStyle(element);
    if (style.display === "none" || style.visibility === "hidden" || style.opacity === "0" || style.pointerEvents === "none") return false;
    return true;
  }

  // src/content/sites/gemini.ts
  var GEMINI_ORIGIN = "https://gemini.google.com";
  var GEMINI_HOME_URL = `${GEMINI_ORIGIN}/`;
  var GEMINI_APP_PREFIX = "/app/";
  var DEFAULT_INPUT_TIMEOUT_MS4 = 9e3;
  var DEFAULT_CLIPBOARD_TIMEOUT_MS3 = 900;
  var DEFAULT_CLIPBOARD_POLL_MS3 = 40;
  var GEMINI_SELECTORS = {
    editor: 'div.ql-editor[contenteditable="true"], rich-textarea div[contenteditable="true"]',
    sendButton: 'button.send-button[aria-label*="\u53D1\u9001"], button.send-button[aria-label*="Send"], button[aria-label*="Send message"], button[aria-label*="\u53D1\u9001\u6D88\u606F"]',
    response: "model-response, .model-response-text, message-content",
    copyButton: 'button[data-test-id="copy-button"], copy-button button, button[mattooltip="\u590D\u5236\u56DE\u7B54"], button[aria-label="\u590D\u5236"], button[aria-label*="Copy"], button[aria-label*="\u590D\u5236"]',
    turn: "model-response"
  };
  var SKIP_TAGS4 = /* @__PURE__ */ new Set([
    "MAT-ICON",
    "SCRIPT",
    "STYLE",
    "BUTTON",
    "MS-THOUGHT-CHUNK",
    "MAT-EXPANSION-PANEL-HEADER"
  ]);
  function createGeminiAdapter(options = {}) {
    const inputTimeoutMs = options.inputTimeoutMs ?? DEFAULT_INPUT_TIMEOUT_MS4;
    const clipboardTimeoutMs = options.clipboardTimeoutMs ?? DEFAULT_CLIPBOARD_TIMEOUT_MS3;
    const clipboardPollMs = options.clipboardPollMs ?? DEFAULT_CLIPBOARD_POLL_MS3;
    function currentHref() {
      return options.href ?? location.href;
    }
    function getConversationSnapshot() {
      return getGeminiConversationLocation(currentHref());
    }
    function getConversationId() {
      return getConversationSnapshot().conversationId || "__default__";
    }
    function getResponseContainers() {
      return [...document.querySelectorAll(GEMINI_SELECTORS.response)];
    }
    function getAllAssistantReplies() {
      return keepDeepestResponseContainers(getResponseContainers()).map((container) => extractCleanText4(container)).filter(Boolean);
    }
    async function fillAndSend2(content, autoSend = true) {
      const editor = await waitForElement(GEMINI_SELECTORS.editor, inputTimeoutMs);
      setContentEditableText(editor, content);
      if (readEditorText(editor) !== content.trim()) {
        throw new Error("Gemini editor did not accept the prompt text");
      }
      if (!autoSend) return;
      const sendButton = await waitForClickableButton(GEMINI_SELECTORS.sendButton, inputTimeoutMs, "Gemini \u53D1\u9001\u6309\u94AE\u6682\u4E0D\u53EF\u7528\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5");
      sendButton.click();
    }
    return {
      id: "gemini",
      getConversationSnapshot,
      getConversationId,
      getResponseContainers,
      getAllAssistantReplies,
      readResponseText: extractCleanText4,
      readResponseTextFromCopy: (node) => readResponseTextFromCopy3(node, clipboardTimeoutMs, clipboardPollMs),
      readResponseMarkdown: extractMarkdownFromDom,
      findResponseContainer: findResponseContainer4,
      isGenerating: isGeminiGenerating,
      stopGenerating: stopGeminiGenerating,
      fillAndSend: fillAndSend2,
      collectPromptDiagnostics: collectPromptDiagnostics4
    };
  }
  function getGeminiConversationLocation(href) {
    const url = parseSafeGeminiUrl(href);
    if (!url) return {};
    return {
      conversationId: extractConversationId4(url),
      conversationUrl: url.href
    };
  }
  function parseSafeGeminiUrl(value) {
    if (!value || !value.startsWith(GEMINI_HOME_URL)) return void 0;
    try {
      const url = new URL(value);
      return url.protocol === "https:" && url.hostname === "gemini.google.com" ? url : void 0;
    } catch {
      return void 0;
    }
  }
  function extractConversationId4(url) {
    if (!url.pathname.startsWith(GEMINI_APP_PREFIX)) return void 0;
    const conversationId = url.pathname.slice(GEMINI_APP_PREFIX.length).split("/")[0];
    return conversationId ? decodeURIComponent(conversationId) : void 0;
  }
  function collectPromptDiagnostics4() {
    return {
      href: location.href,
      readyState: document.readyState,
      visibilityState: document.visibilityState,
      title: document.title,
      editorMatches: [...document.querySelectorAll(GEMINI_SELECTORS.editor)].slice(0, 5).map(describeElement),
      sendButtonMatches: [...document.querySelectorAll(GEMINI_SELECTORS.sendButton)].slice(0, 5).map(describeElement),
      visibleButtonSamples: [...document.querySelectorAll("button")].slice(0, 12).map(describeElement)
    };
  }
  function extractCleanText4(node) {
    return extractCleanTextFromDom(node, { skipTags: SKIP_TAGS4 });
  }
  function findResponseContainer4(element) {
    return findClosestMatchingAncestor(element, GEMINI_SELECTORS.response);
  }
  async function readResponseTextFromCopy3(node, timeoutMs, pollMs) {
    return readResponseTextFromCopyAction({ node, timeoutMs, pollMs, findCopyButton: findCopyButton3 });
  }
  function findCopyButton3(response) {
    const turn = response.closest(GEMINI_SELECTORS.turn) ?? response.parentElement;
    return findClickableCopyButton(turn, GEMINI_SELECTORS.copyButton);
  }
  function isGeminiGenerating() {
    return Boolean(findGeminiStopButton());
  }
  async function stopGeminiGenerating() {
    const button = findGeminiStopButton();
    if (!button) return false;
    button.click();
    return true;
  }
  function findGeminiStopButton() {
    return [...document.querySelectorAll("button")].find((button) => buttonLabelMatches(button, /stop|stopping|停止|中止/) && isClickableButton(button));
  }

  // src/content/sites/kimi.ts
  var KIMI_HOST = "www.kimi.com";
  var KIMI_ORIGIN = `https://${KIMI_HOST}`;
  var KIMI_HOME_URL = `${KIMI_ORIGIN}/chat/`;
  var DEFAULT_INPUT_TIMEOUT_MS5 = 9e3;
  var KIMI_SELECTORS = {
    editor: '.chat-input-editor[contenteditable="true"][data-lexical-editor="true"], .chat-input-editor[role="textbox"][contenteditable="true"]',
    composer: ".chat-editor",
    response: ".chat-content-item-assistant .markdown-container:not(.toolcall-content-text) > .markdown",
    responseContainer: ".chat-content-item-assistant",
    sendButton: ".send-button-container"
  };
  var SKIP_TAGS5 = /* @__PURE__ */ new Set(["SCRIPT", "STYLE", "BUTTON", "TEXTAREA", "SVG", "CANVAS"]);
  function createKimiAdapter(options = {}) {
    const inputTimeoutMs = options.inputTimeoutMs ?? DEFAULT_INPUT_TIMEOUT_MS5;
    function currentHref() {
      return options.href ?? location.href;
    }
    function getConversationSnapshot() {
      return getKimiConversationLocation(currentHref());
    }
    function getConversationId() {
      return getConversationSnapshot().conversationId || "__default__";
    }
    function getResponseContainers() {
      return [...document.querySelectorAll(KIMI_SELECTORS.response)].filter(isFinalResponseMarkdown2);
    }
    function getAllAssistantReplies() {
      return keepDeepestResponseContainers(getResponseContainers()).map((container) => extractCleanText5(container)).filter(Boolean);
    }
    async function fillAndSend2(content, autoSend = true) {
      const editor = await waitForElement(KIMI_SELECTORS.editor, inputTimeoutMs);
      if (!(editor instanceof HTMLElement)) {
        throw new Error("Kimi editor is not an editable element");
      }
      setKimiEditorText(editor, content);
      if (readEditorText(editor) !== content.trim()) {
        throw new Error("Kimi editor did not accept the prompt text");
      }
      if (!autoSend) return;
      const sendButton = await waitForKimiSendButton(editor, inputTimeoutMs);
      sendButton.click();
    }
    return {
      id: "kimi",
      getConversationSnapshot,
      getConversationId,
      getResponseContainers,
      getAllAssistantReplies,
      readResponseText: extractCleanText5,
      readResponseMarkdown: extractMarkdownFromDom,
      findResponseContainer: findResponseContainer5,
      isGenerating: isKimiGenerating,
      stopGenerating: stopKimiGenerating,
      fillAndSend: fillAndSend2,
      collectPromptDiagnostics: collectPromptDiagnostics5
    };
  }
  function getKimiConversationLocation(href) {
    const url = parseSafeKimiUrl(href);
    if (!url) return {};
    return {
      conversationId: extractConversationId5(url),
      conversationUrl: url.href
    };
  }
  function parseSafeKimiUrl(value) {
    if (!value || !value.startsWith(`${KIMI_ORIGIN}/`)) return void 0;
    try {
      const url = new URL(value);
      return url.protocol === "https:" && url.hostname === KIMI_HOST ? url : void 0;
    } catch {
      return void 0;
    }
  }
  function extractConversationId5(url) {
    if (!url.href.startsWith(KIMI_HOME_URL)) return void 0;
    const conversationId = url.pathname.slice("/chat/".length).split("/")[0];
    return conversationId ? decodeURIComponent(conversationId) : void 0;
  }
  function setKimiEditorText(editor, content) {
    if (insertTextWithNativeEditing(editor, content)) return;
    editor.focus();
    editor.replaceChildren();
    const block2 = document.createElement("p");
    block2.textContent = content;
    editor.append(block2);
    editor.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertReplacementText" }));
    editor.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function insertTextWithNativeEditing(editor, content) {
    if (typeof document.execCommand !== "function") return false;
    editor.focus();
    const selection = window.getSelection();
    if (!selection) return false;
    const range = document.createRange();
    range.selectNodeContents(editor);
    selection.removeAllRanges();
    selection.addRange(range);
    document.execCommand("delete", false);
    const inserted = document.execCommand("insertText", false, content);
    return inserted && readEditorText(editor) === content.trim();
  }
  async function waitForKimiSendButton(editor, timeoutMs) {
    const startedAt = Date.now();
    while (Date.now() - startedAt <= timeoutMs) {
      const button = findKimiSendButton(editor);
      if (button) return button;
      await new Promise((resolve) => window.setTimeout(resolve, 50));
    }
    throw new Error("Kimi \u53D1\u9001\u6309\u94AE\u6682\u4E0D\u53EF\u7528\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5");
  }
  function findKimiSendButton(editor) {
    const composer = editor.closest(KIMI_SELECTORS.composer) ?? document.body;
    const candidates = [...composer.querySelectorAll(KIMI_SELECTORS.sendButton)];
    return candidates.reverse().find(isClickableKimiControl);
  }
  function collectPromptDiagnostics5() {
    return {
      href: location.href,
      readyState: document.readyState,
      visibilityState: document.visibilityState,
      title: document.title,
      editorMatches: [...document.querySelectorAll(KIMI_SELECTORS.editor)].slice(0, 5).map(describeElement),
      sendButtonMatches: [...document.querySelectorAll(KIMI_SELECTORS.sendButton)].slice(0, 5).map(describeElement),
      visibleButtonSamples: [...document.querySelectorAll('[role="button"], button, .icon-button, .send-button-container')].slice(0, 12).map(describeElement)
    };
  }
  function extractCleanText5(node) {
    return extractCleanTextFromDom(node, { skipTags: SKIP_TAGS5 });
  }
  function findResponseContainer5(element) {
    const finalMarkdown = findClosestMatchingAncestor(element, KIMI_SELECTORS.response);
    return finalMarkdown && isFinalResponseMarkdown2(finalMarkdown) ? finalMarkdown : null;
  }
  function isFinalResponseMarkdown2(element) {
    if (element.closest(".thinking-container, .toolcall-container")) return false;
    return Boolean(element.closest(KIMI_SELECTORS.responseContainer));
  }
  function isKimiGenerating() {
    return Boolean(findKimiStopButton());
  }
  async function stopKimiGenerating() {
    const button = findKimiStopButton();
    if (!button) return false;
    button.click();
    return true;
  }
  function findKimiStopButton() {
    const explicit = [...document.querySelectorAll('svg[name="Stop"], svg[name="Pause"]')].map((icon) => icon.closest('.send-button-container, .icon-button, button, [role="button"]')).find((button) => button !== null && isClickableKimiControl(button));
    if (explicit) return explicit;
    return [...document.querySelectorAll('[role="button"], button, .icon-button, .send-button-container')].find(
      (button) => buttonLabelMatches(button, /stop|stopping|停止|中止/) && isClickableKimiControl(button)
    );
  }
  function isClickableKimiControl(element) {
    if (element.getAttribute("aria-disabled") === "true") return false;
    if (element instanceof HTMLButtonElement && element.disabled) return false;
    if (element.classList.contains("disabled")) return false;
    const style = window.getComputedStyle(element);
    if (style.display === "none" || style.visibility === "hidden" || style.opacity === "0" || style.pointerEvents === "none") return false;
    return true;
  }

  // src/content/sites/index.ts
  function getActiveChatSiteAdapter() {
    if (location.hostname === "claude.ai") return createClaudeAdapter();
    if (location.hostname === "chat.deepseek.com") return createDeepSeekAdapter();
    if (location.hostname === "www.kimi.com") return createKimiAdapter();
    if (location.hostname === "chatgpt.com" || location.hostname === "chat.openai.com") return createChatGptAdapter();
    return createGeminiAdapter();
  }

  // src/content/index.ts
  var OPEN_TEAM_LOADED_KEY = "__OPENTEAM_LOADED__";
  var siteAdapter = getActiveChatSiteAdapter();
  var replyObserver;
  var conversationMonitor;
  var roleSession = createRoleSession({
    siteAdapter,
    log: contentLog,
    onAssigned() {
      replyObserver?.resetForAssignedRole();
      conversationMonitor?.reportConversationUpdate(true);
    }
  });
  conversationMonitor = createConversationMonitor({
    siteAdapter,
    roleSession,
    log: contentLog,
    sendRuntimeMessage: (message) => sendBackgroundMessage(message)
  });
  replyObserver = createReplyObserver({
    siteAdapter,
    roleSession,
    log: contentLog,
    sendRuntimeMessage: (message) => sendBackgroundMessage(message),
    reportRoleError
  });
  function collectPromptDiagnostics6() {
    return {
      site: siteAdapter.id,
      assignedRole: roleSession.getAssignedRole(),
      ...siteAdapter.collectPromptDiagnostics()
    };
  }
  function sendBackgroundMessage(message) {
    return sendRuntimeMessage(message, contentLog);
  }
  async function fillAndSend(content, autoSend = true) {
    contentLog.info("fill-send:start", { site: siteAdapter.id, contentLength: content.length, autoSend, diagnostics: collectPromptDiagnostics6() });
    await siteAdapter.fillAndSend(content, autoSend);
    contentLog.info("fill-send:done", { site: siteAdapter.id, contentLength: content.trim().length, autoSend });
  }
  function reportRoleError(messageId, reason, chatId = roleSession.getAssignedChatId(), roleId = roleSession.getAssignedRole()?.roleId || "", replyAttemptId = roleSession.getActiveReplyAttemptId()) {
    const assignedRole = roleSession.getAssignedRole();
    if (!chatId || !roleId) {
      contentLog.warn("role-error:skipped-missing-identity", { messageId, reason, assignedRole });
      return;
    }
    contentLog.warn("role-error:report", { chatId, roleId, messageId, reason, diagnostics: collectPromptDiagnostics6() });
    sendBackgroundMessage({
      type: "TEAM_ROLE_ERROR",
      chatId,
      roleId,
      messageId,
      replyAttemptId,
      reason
    }).catch((error) => contentLog.warn("role-error:failed", { error: error instanceof Error ? error.message : String(error) }));
  }
  function registerMessageHandlers() {
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message?.type === "TEAM_SEND_PROMPT") {
        handleSendPromptMessage(message, sendResponse);
        return true;
      }
      if (message?.type === "TEAM_STOP_GENERATION") {
        handleStopGenerationMessage(message, sendResponse);
        return true;
      }
      return false;
    });
  }
  function handleStopGenerationMessage(message, sendResponse) {
    const activePrompt = roleSession.getActivePrompt();
    contentLog.info("message:stop-generation", {
      chatId: message.chatId,
      roleId: message.roleId,
      messageId: message.messageId,
      activeMessageId: activePrompt?.messageId
    });
    if (activePrompt && (message.messageId && activePrompt.messageId !== message.messageId || message.replyAttemptId && activePrompt.replyAttemptId && activePrompt.replyAttemptId !== message.replyAttemptId)) {
      sendResponse({ ok: false, error: "\u5F53\u524D\u56DE\u590D\u5DF2\u7ECF\u5207\u6362\uFF0C\u505C\u6B62\u8BF7\u6C42\u5DF2\u8FC7\u671F" });
      return;
    }
    siteAdapter.stopGenerating().then((stopped) => {
      if (!stopped) {
        sendResponse({ ok: false, error: "\u5F53\u524D\u9875\u9762\u6CA1\u6709\u53EF\u70B9\u51FB\u7684\u505C\u6B62\u6309\u94AE" });
        return;
      }
      roleSession.clearActivePrompt(message.messageId);
      replyObserver?.clearPromptReplyBaseline();
      replyObserver?.clearReplyPolling();
      sendResponse({ ok: true });
    }).catch((error) => {
      sendResponse({ ok: false, error: error instanceof Error ? error.message : String(error) });
    });
  }
  function handleSendPromptMessage(message, sendResponse) {
    const promptChatId = message.chatId || roleSession.getAssignedChatId();
    const promptRoleId = message.roleId || roleSession.getAssignedRole()?.roleId || "";
    contentLog.info("message:send-prompt", {
      chatId: promptChatId,
      roleId: promptRoleId,
      messageId: message.messageId,
      contentLength: message.content.length,
      autoSend: message.autoSend
    });
    replyObserver?.capturePromptReplyBaseline(message.messageId);
    roleSession.startPrompt(message.messageId, message.replyAttemptId);
    sendBackgroundMessage({ type: "TEAM_ROLE_STATUS", status: "sending" }).then(() => {
      contentLog.info("message:send-prompt:delay-before-input", { messageId: message.messageId, delayMs: PROMPT_INPUT_DELAY_MS });
      return waitBeforePromptInput();
    }).then(() => fillAndSend(message.content, message.autoSend !== false)).then(() => {
      conversationMonitor?.reportConversationUpdate();
      if (promptChatId && promptRoleId) {
        sendBackgroundMessage({ type: "TEAM_SEND_ACK", chatId: promptChatId, roleId: promptRoleId, messageId: message.messageId }).catch(
          (error) => contentLog.warn("message:send-prompt:ack-failed", { messageId: message.messageId, error: error instanceof Error ? error.message : String(error) })
        );
      }
    }).then(() => sendBackgroundMessage({ type: "TEAM_ROLE_STATUS", status: "generating" })).then(() => {
      replyObserver?.startReplyPolling(message.messageId, message.replyAttemptId);
      contentLog.info("message:send-prompt:ok", { messageId: message.messageId });
      sendResponse({ ok: true, messageId: message.messageId });
    }).catch((error) => {
      const reason = error instanceof Error ? error.message : String(error);
      contentLog.warn("message:send-prompt:failed", { messageId: message.messageId, error: reason, diagnostics: collectPromptDiagnostics6() });
      roleSession.clearActivePrompt(message.messageId);
      replyObserver?.clearPromptReplyBaseline();
      replyObserver?.clearReplyPolling();
      reportRoleError(message.messageId, reason, promptChatId, promptRoleId, message.replyAttemptId);
      sendBackgroundMessage({ type: "TEAM_ROLE_STATUS", status: "error", error: reason }).catch(() => void 0);
      sendResponse({ ok: false, messageId: message.messageId, error: reason });
    });
  }
  function startOpenTeam() {
    const embedded = isEmbeddedFrame();
    const directEmbedded = isDirectEmbeddedFrame();
    contentLog.info("boot", { href: location.href, conversationId: siteAdapter.getConversationId(), embedded, directEmbedded });
    registerMessageHandlers();
    if (embedded) {
      if (directEmbedded) {
        conversationMonitor?.start();
        replyObserver?.startReplyReporting();
        registerFrameRoleHandshake({
          siteAdapter,
          roleSession,
          log: contentLog,
          seedStoredRoleReplies: (replies) => replyObserver?.seedStoredRoleReplies(replies),
          sendRuntimeMessage: (message) => sendBackgroundMessage(message)
        });
      }
      return;
    }
    conversationMonitor?.start();
    replyObserver?.startReplyReporting();
  }
  function bootWhenReady() {
    if (document.body) {
      startOpenTeam();
      return;
    }
    document.addEventListener("DOMContentLoaded", startOpenTeam, { once: true });
  }
  if (!window[OPEN_TEAM_LOADED_KEY]) {
    ;
    window[OPEN_TEAM_LOADED_KEY] = true;
    bootWhenReady();
  }
})();
